package minecraftbot.gui;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;

public abstract class GUIObject implements KeyListener {
	//MouseEvent und KeyEvent sollten vom Frame implementiert werden, MouseEvent auch von einem Label
	public int x, y, width, height;
	private boolean insideObject;
	private boolean keyEventEnabled;
	public void setLocation(int x, int y) {
		this.x = x;
		this.y = y;
	}
	/**
	 * Pr�ft, ob sich der Punkt aus x und y innerhalb dieses Objektes befindet.
	 * @param x x-Koordinate
	 * @param y y-Koordinate
	 * @return
	 */
	public boolean insideObject(int x, int y) {
		if (this.x <= x && this.x + this.width >= x && this.y <= y && this.y + this.height >= y) {
			return true;
		}
		return false;
	}
	public void setSize(int width, int height) {
		this.width = width;
		this.height = height;
	}
	public void handleKeyPressed(KeyEvent event) {
		this.keyPressed(event.getKeyCode(), event.getKeyChar());
	}
	protected abstract void keyPressed(int keyCode, char keyChar);
	/**
	 * Methode soll vom MouseEvent des Frames aufgerufen werden
	 * @param event
	 */
	public void handleMousePressed() {
		
	}
	/**
	 * Methode soll vom MouseEvent des Frames aufgerufen werden
	 * @param event
	 */
	public void handleMouseReleased(MouseEvent event) {
		
	}
	/**
	 * Methode soll vom MouseEvent des Labels aufgerufen werden
	 * @param event
	 */
	public void handleMouseEntered(MouseEvent event) {
		
	}
	/**
	 * Methode soll vom MouseEvent des Labels aufgerufen werden
	 * @param event
	 */
	public void handleMouseExited(MouseEvent event) {
		
	}
	
}
