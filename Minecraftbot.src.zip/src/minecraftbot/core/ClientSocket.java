package minecraftbot.core;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

public class ClientSocket {
	public static final String EXAMPLEPASSWORD = "password";
	public Socket socket;
	public InetSocketAddress host;
	public DataOutputStream output;
	public DataInputStream input;
	public ClientSocket(String ip, int port) throws Exception {
		host = new InetSocketAddress(ip, port);
		socket = new Socket();
		socket.connect(host, 30000);
		output = new DataOutputStream(socket.getOutputStream());
		input = new DataInputStream(socket.getInputStream());
	}
}
