package minecraftbot.core;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Proxy;
import java.security.PublicKey;
import java.util.Random;

import minecraftbot.authmojang.Account;
import minecraftbot.authmojang.Auth;
import minecraftbot.datamanaging.Packet;
import minecraftbot.datamanaging.SpecialDataManager;
import minecraftbot.packet.EncryptionResponse;
import minecraftbot.packet.Handshake;
import minecraftbot.packet.KeepAliveResponse;
import minecraftbot.packet.LoginStart;
import minecraftbot.packet.SendMessage;
import minecraftbot.packet.in.ChatMessage;
import minecraftbot.packet.in.Disconnect;
import minecraftbot.packet.in.DisconnectPlay;
import minecraftbot.packet.in.EncryptionRequest;
import minecraftbot.packet.in.KeepAliveInput;
import minecraftbot.packet.in.LoginSuccess;

public class Client implements Runnable {
	public ClientSocket socket;
	public byte[] sharedSecret;
	public boolean crypted;
	public DataInputStream cryptInput;
	public DataOutputStream cryptOutput;
	private boolean disconnected;
	public void disconnect() throws Exception {
		disconnected = true;
		socket.socket.close();
	}
	public Client(String serverIP, int port, String playerName, int version) throws Exception {
		this(serverIP, port, playerName, version, null, null);
	}
	public Client(String serverIP, int port, String playerName, int version, String username, String password) throws Exception {
		socket = new ClientSocket(serverIP, port);
		Account acc = null;
		if (username != null) {
			acc = Auth.login(username, password);
		}
		Packet handshake = new Packet(new Handshake(version, serverIP, port));
		Packet loginStart = new Packet(new LoginStart(playerName));
		handshake.send(socket.output);
		loginStart.send(socket.output);
		SpecialDataManager.readVarInt(socket.input);
		int packetId = SpecialDataManager.readVarInt(socket.input);
		cryptInput = socket.input;
		cryptOutput = socket.output;
		if (packetId == 0x01) {
			crypted = true;
			EncryptionRequest req = new EncryptionRequest(socket.input);
			sharedSecret = new byte[16];
			new Random().nextBytes(sharedSecret);
			Auth.authenticate(req.serverID, sharedSecret, req.publicKey, acc.accesstoken, acc.uuid);
			//Test
			PublicKey key = Auth.generatePublicKey(req.publicKey);
			cryptInput = Auth.generateCryptDataInputStream(sharedSecret, socket.input);
			cryptOutput = Auth.generateCryptDataOutputStream(sharedSecret, socket.output);
			//Test
			Packet response = new Packet(new EncryptionResponse(Auth.encrypt(key, sharedSecret), Auth.encrypt(key, req.verifyToken)));
			response.send(socket.output);
			SpecialDataManager.readVarInt(cryptInput);
			packetId = SpecialDataManager.readVarInt(cryptInput);
		}
		if (packetId == 0x03) {
			System.err.println("Fehler: Packet-Komprimierung wird nicht unterst�tzt.");
			socket.socket.close();
			return;
		}
		if (packetId == 0x02) {
			System.out.println("Erfolgreich eingeloggt!");
			new LoginSuccess(cryptInput);
			new Thread(this).start();
			return;
		}
		if (packetId == 0x00) {
			Disconnect disconnect = null;
			if (crypted) {
				disconnect = new Disconnect(cryptInput);
			}
			else {
				disconnect = new Disconnect(socket.input);
			}
			System.out.println("Verbindungsaufbau fehlgeschlagen: " + disconnect.reason);
			socket.socket.close();
			return;
		}
	}
	public Client(String serverIP, int port, String playerName, int version, String username, String password, Proxy proxy) throws Exception {
		socket = new ClientSocket(serverIP, port);
		Account acc = null;
		if (username != null) {
			acc = Auth.login(username, password, proxy);
		}
		Packet handshake = new Packet(new Handshake(version, serverIP, port));
		Packet loginStart = new Packet(new LoginStart(playerName));
		handshake.send(socket.output);
		loginStart.send(socket.output);
		SpecialDataManager.readVarInt(socket.input);
		int packetId = SpecialDataManager.readVarInt(socket.input);
		cryptInput = socket.input;
		cryptOutput = socket.output;
		if (packetId == 0x01) {
			crypted = true;
			EncryptionRequest req = new EncryptionRequest(socket.input);
			sharedSecret = new byte[16];
			new Random().nextBytes(sharedSecret);
			Auth.authenticate(req.serverID, sharedSecret, req.publicKey, acc.accesstoken, acc.uuid);
			//Test
			PublicKey key = Auth.generatePublicKey(req.publicKey);
			cryptInput = Auth.generateCryptDataInputStream(sharedSecret, socket.input);
			cryptOutput = Auth.generateCryptDataOutputStream(sharedSecret, socket.output);
			//Test
			Packet response = new Packet(new EncryptionResponse(Auth.encrypt(key, sharedSecret), Auth.encrypt(key, req.verifyToken)));
			response.send(socket.output);
			SpecialDataManager.readVarInt(cryptInput);
			packetId = SpecialDataManager.readVarInt(cryptInput);
		}
		if (packetId == 0x03) {
			System.err.println("Fehler: Packet-Komprimierung wird nicht unterst�tzt.");
			socket.socket.close();
			return;
		}
		if (packetId == 0x02) {
			System.out.println("Erfolgreich eingeloggt!");
			new LoginSuccess(cryptInput);
			new Thread(this).start();
			return;
		}
		if (packetId == 0x00) {
			Disconnect disconnect = null;
			if (crypted) {
				disconnect = new Disconnect(cryptInput);
			}
			else {
				disconnect = new Disconnect(socket.input);
			}
			System.out.println("Verbindungsaufbau fehlgeschlagen: " + disconnect.reason);
			socket.socket.close();
			return;
		}
	}
	/**
	 * Methode f�r das dauerhafte lesen des datainputstreams
	 */
	public void run() {
		while(!disconnected) {
			try {
				int length = SpecialDataManager.readVarInt(cryptInput);
				byte[] data = new byte[length];
				cryptInput.readFully(data);
				DataInputStream input = new DataInputStream(new ByteArrayInputStream(data));
				int packetID = SpecialDataManager.readVarInt(input);
				if (packetID == 0x40) {
					System.out.println("Verbindung unterbrochen: " + new DisconnectPlay(input).reason);
					try {
						this.disconnect();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return;
				}
				if (packetID == 0x00) {
					int keepAliveID = new KeepAliveInput(input).keepAliveID;
					Packet response = new Packet(new KeepAliveResponse(keepAliveID));
					try {
						response.send(cryptOutput);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					continue;
				}
				if (packetID == 0x02) {
					ChatMessage chat = new ChatMessage(input);
					switch(chat.position) {
					case 0:
						System.out.println("[Chat] " + chat.message);
						break;
					case 1:
						System.out.println("[System Message] " + chat.message);
						break;
					case 2:
						System.out.println("[Game Info] " + chat.message);
						break;
					default:
					}
					continue;
				}
			}
			catch (IOException e) {
				
			}
		}
	}
	public void sendMessage(String message) throws Exception {
		Packet sendMessage = new Packet(new SendMessage(message));
		sendMessage.send(cryptOutput);
	}
}
