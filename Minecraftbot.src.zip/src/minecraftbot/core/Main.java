package minecraftbot.core;

public class Main {
}
