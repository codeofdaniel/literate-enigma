package minecraftbot.core;

import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.Scanner;

import minecraftproxy.tor.TorControl;

public class Test {
	public static Proxy getProxy(String ip, int port) {
		return new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(ip,port));
	}
	public static Proxy getHTTPProxy(String ip, int port) {
		return new Proxy(Proxy.Type.HTTP, new InetSocketAddress(ip,port));
	}
	public static void main(String[] args) throws Exception {
		if (false) {
		try {
			TorControl tc = new TorControl();
			tc.authenticate();
			tc.useProxy();
		}
		catch (Exception e) {
			e.printStackTrace();
			return;
		}}
		Client test = new Client("example.com",25565,"Player",47,"max.mustermann@example.com",ClientSocket.EXAMPLEPASSWORD);
		if (test.socket.socket.isClosed()) {
			return;
		}
		Scanner scanner = new Scanner(new InputStreamReader(System.in));
		while(true) {
			String command = scanner.nextLine();
			if (test.socket.socket.isClosed()) {
				scanner.close();
				return;
			}
			if (command.equals("#EXIT")) {
				test.disconnect();
				scanner.close();
				return;
			}
			test.sendMessage(command);
		}
	}
}
