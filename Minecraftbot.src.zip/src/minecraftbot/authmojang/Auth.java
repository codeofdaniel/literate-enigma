package minecraftbot.authmojang;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Scanner;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import minecraftbot.datamanaging.SpecialDataManager;

public class Auth {
	/**
	 * Methode wird beim Verbinden mit einem Minecraft Premium Server benutzt
	 * @param serverId
	 * @param sharedSecret
	 * @param publicKey
	 * @param accessToken
	 * @param uuid
	 * @throws Exception
	 */
	public static void authenticate(String serverId, byte[] sharedSecret, byte[] publicKey, String accessToken, String uuid) throws Exception {
		String hexdigest = hash(serverId, sharedSecret, publicKey);
		String data = "{\"accessToken\":\"" + accessToken + "\",\"selectedProfile\":\"" + uuid + "\",\"serverId\":\"" + hexdigest + "\"}";
		byte[] contentBytes = data.getBytes("UTF-8");
		URL url = new URL("https://sessionserver.mojang.com/session/minecraft/join");
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setDoInput( true );
		connection.setDoOutput( true );
		connection.setRequestProperty("Accept-Charset", "UTF-8");
		connection.setRequestProperty( "Content-Type","application/json" );
		connection.setRequestProperty("Content-Length", Integer.toString(contentBytes.length));
		OutputStream requestStream = connection.getOutputStream();
	    requestStream.write(contentBytes, 0, contentBytes.length);
	    requestStream.close();
	    new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8")).close();
	}
	public static PublicKey generatePublicKey(byte[] key) throws Exception {
		X509EncodedKeySpec spec = new X509EncodedKeySpec(key);
		KeyFactory kf = KeyFactory.getInstance("RSA");
		return kf.generatePublic(spec);
	}
	public static byte[] encrypt(PublicKey key, byte[] plaintext) throws Exception
	{
	    Cipher cipher = Cipher.getInstance("RSA");   
	    cipher.init(Cipher.ENCRYPT_MODE, key);  
	    return cipher.doFinal(plaintext);
	}
	public static DataInputStream generateCryptDataInputStream(byte[] sharedSecret, DataInputStream is) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(sharedSecret, "AES");
		IvParameterSpec ivSpec = new IvParameterSpec(sharedSecret);
		Cipher cipher = Cipher.getInstance("AES/CFB8/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);
        return new DataInputStream(new CipherInputStream(is,cipher));
	}
	public static DataOutputStream generateCryptDataOutputStream(byte[] sharedSecret, DataOutputStream os) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(sharedSecret, "AES");
		IvParameterSpec ivSpec = new IvParameterSpec(sharedSecret);
		Cipher cipher = Cipher.getInstance("AES/CFB8/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);
        return new DataOutputStream(new CipherOutputStream(os,cipher));
	}


	public static String hash(String serverID, byte[] sharedSecret, byte[] publicKey) {

		try {

			byte[] digest = digest(serverID, sharedSecret, publicKey);

			return new BigInteger(digest).toString(16);

		} catch (Exception e) {

			throw new RuntimeException(e);

		}

	}



	private static byte[] digest(String serverID, byte[] sharedSecret, byte[] publicKey) throws Exception {
		MessageDigest md = MessageDigest.getInstance("SHA-1");
		md.update(SpecialDataManager.stringToBytesASCII(serverID));
		md.update(sharedSecret);
		md.update(publicKey);
		return md.digest();
	}
	public static Account login(String username, String password) throws Exception {
		String response = auth(username, password);
		Account acc = new Account();
		acc.username = getUsername(response);
		acc.accesstoken = getAccessToken(response);
		acc.uuid = getUUID(response);
		return acc;
	}
	public static Account login(String username, String password, Proxy proxy) throws Exception {
		String response = auth(username, password, proxy);
		Account acc = new Account();
		acc.username = getUsername(response);
		acc.accesstoken = getAccessToken(response);
		acc.uuid = getUUID(response);
		return acc;
	}
	public static void main(String[] args) throws Exception {
		System.out.println("USERNAME:PASSWORD");
		Scanner scanner = new Scanner(new InputStreamReader(System.in));
		String[] s = scanner.nextLine().split(":");
		String u = s[0];
		String p = s[1];
		scanner.close();
		File pasteFile = new File(new File(Auth.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getParentFile(), "paste.txt");
		PrintWriter pw = new PrintWriter(new FileWriter(pasteFile));
		pw.println(getEncoded(u,p));
		pw.close();
	}
	private static String getEncoded(String username, String password) {
		try {
			return URLEncoder.encode("{\"agent\": { \"name\": \"Minecraft\", \"version\": 1 }, \"username\": \"" + username + "\", \"password\": \"" + password + "\"}", "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	private static String auth(String username, String password) throws Exception {
	    URL url = new URL("https://authserver.mojang.com/authenticate");
	    String data = "{\"agent\": { \"name\": \"Minecraft\", \"version\": 1 }, \"username\": \"" + username + "\", \"password\": \"" + password + "\"}";
	    byte[] contentBytes = data.getBytes("UTF-8");
	    
	    HttpURLConnection connection = (HttpURLConnection)url.openConnection();
	    connection.setDoInput(true);
	    connection.setDoOutput(true);
	    connection.setRequestProperty("Accept-Charset", "UTF-8");
	    connection.setRequestProperty("Content-Type", "application/json");
	    connection.setRequestProperty("Content-Length", Integer.toString(contentBytes.length));

	    OutputStream requestStream = connection.getOutputStream();
	    requestStream.write(contentBytes, 0, contentBytes.length);
	    requestStream.close();

	    String response;
	    BufferedReader responseStream;
	    if (connection.getResponseCode() == 200) {
	        responseStream = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
	    } else {
	        responseStream = new BufferedReader(new InputStreamReader(connection.getErrorStream(), "UTF-8"));
	    }

	    response = responseStream.readLine();
	    responseStream.close();

	    if (connection.getResponseCode() == 200) {
	        return response;
	    } else {
	        // Failed to log in; response will contain data about why
	        System.err.println(response);
	        System.err.println("responseCode: " + connection.getResponseCode());
	        return null;
	    }
	}
	private static String auth(String username, String password, Proxy proxy) throws Exception {
	    URL url = new URL("https://authserver.mojang.com/authenticate");
	    String data = "{\"agent\": { \"name\": \"Minecraft\", \"version\": 1 }, \"username\": \"" + username + "\", \"password\": \"" + password + "\"}";
	    byte[] contentBytes = data.getBytes("UTF-8");
	    
	    HttpURLConnection connection = (HttpURLConnection)url.openConnection(proxy);
	    connection.setDoInput(true);
	    connection.setDoOutput(true);
	    connection.setRequestProperty("Accept-Charset", "UTF-8");
	    connection.setRequestProperty("Content-Type", "application/json");
	    connection.setRequestProperty("Content-Length", Integer.toString(contentBytes.length));

	    OutputStream requestStream = connection.getOutputStream();
	    requestStream.write(contentBytes, 0, contentBytes.length);
	    requestStream.close();

	    String response;
	    BufferedReader responseStream;
	    if (connection.getResponseCode() == 200) {
	        responseStream = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
	    } else {
	        responseStream = new BufferedReader(new InputStreamReader(connection.getErrorStream(), "UTF-8"));
	    }

	    response = responseStream.readLine();
	    responseStream.close();

	    if (connection.getResponseCode() == 200) {
	        return response;
	    } else {
	        // Failed to log in; response will contain data about why
	        System.err.println(response);
	        System.err.println("responseCode: " + connection.getResponseCode());
	        return null;
	    }
	}
	private static String getAccessToken(String response) {
		char[] cs = response.toCharArray();
		String accessToken = "";
		for (int i = 16; true; i++) {
			if (cs[i] == '"') {
				return accessToken;
			}
			accessToken = accessToken + cs[i];
		}
	}
	private static String getUsername(String response) {
		char[] cs = response.toCharArray();
		String username = "";
		for (int i = 0; true; i++) {
			if (cs[i] == '"' && cs[i+1] == 'n' && cs[i+2] == 'a' && cs[i+3] == 'm' && cs[i+4] == 'e' && cs[i+5] == '"') {
				for (int j = i + 8; true; j++) {
					if (cs[j] == '"') {
						return username;
					}
					username = username + cs[j];
				}
			}
		}
	}
	private static String getUUID(String response) {
		char[] cs = response.toCharArray();
		String uuid = "";
		for (int i = 1; true; i++) {
			if (cs[i-1] == '"' && cs[i] == 'i') {
				if (cs[i+1] == 'd' && cs[i+2] == '"') {
					for (int j = i+5;true;j++) {
						if (cs[j] == '"') {
							return uuid;
						}
						uuid = uuid + cs[j];
					}
				}
			}
		}
	}
}
