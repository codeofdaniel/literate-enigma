package minecraftbot.authmojang;

public class Account {
	public String username, uuid, accesstoken;
}
