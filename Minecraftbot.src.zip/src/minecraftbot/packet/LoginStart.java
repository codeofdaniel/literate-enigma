package minecraftbot.packet;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;

import minecraftbot.datamanaging.DataContent;
import minecraftbot.datamanaging.SpecialDataManager;

public class LoginStart implements DataContent {
	private String player;
	public LoginStart(String playerName) {
		player = playerName;
	}
	@Override
	public void dataContent(DataOutputStream out) {
		try {
			SpecialDataManager.writeVarInt(out, 0x00);
			SpecialDataManager.writeString(out, player, StandardCharsets.UTF_8);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
