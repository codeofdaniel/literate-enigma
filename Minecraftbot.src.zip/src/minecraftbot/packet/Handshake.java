package minecraftbot.packet;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;

import minecraftbot.datamanaging.DataContent;
import minecraftbot.datamanaging.SpecialDataManager;

public class Handshake implements DataContent {
	private int version, port;
	private String ip;
	public Handshake(int protocolVersion, String ip, int port) {
		this.port=port;
		version=protocolVersion;
		this.ip = ip;
	}
	@Override
	public void dataContent(DataOutputStream out) {
		try {
			SpecialDataManager.writeVarInt(out, 0x00);
			SpecialDataManager.writeVarInt(out, version);
			SpecialDataManager.writeString(out, ip, StandardCharsets.UTF_8);
			out.writeShort(port);
			SpecialDataManager.writeVarInt(out, 2);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
