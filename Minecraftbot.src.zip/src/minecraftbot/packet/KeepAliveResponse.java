package minecraftbot.packet;

import java.io.DataOutputStream;

import minecraftbot.datamanaging.DataContent;
import minecraftbot.datamanaging.SpecialDataManager;

public class KeepAliveResponse implements DataContent {
	private int keepAliveID;
	public KeepAliveResponse(int keepAliveID) {
		this.keepAliveID = keepAliveID;
	}
	@Override
	public void dataContent(DataOutputStream out) {
		try {
			SpecialDataManager.writeVarInt(out, 0x00);
			SpecialDataManager.writeVarInt(out, keepAliveID);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
