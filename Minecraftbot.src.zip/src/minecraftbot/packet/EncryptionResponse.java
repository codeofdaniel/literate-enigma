package minecraftbot.packet;

import java.io.DataOutputStream;

import minecraftbot.datamanaging.DataContent;
import minecraftbot.datamanaging.SpecialDataManager;

public class EncryptionResponse implements DataContent {
	private byte[] sharedSecret, verifyToken;
	public EncryptionResponse(byte[] sharedSecret, byte[] verifyToken) {
		this.sharedSecret = sharedSecret;
		this.verifyToken = verifyToken;
	}
	@Override
	public void dataContent(DataOutputStream out) {
		try {
			SpecialDataManager.writeVarInt(out, 0x01);
			SpecialDataManager.writeVarInt(out, sharedSecret.length);
			out.write(sharedSecret);
			SpecialDataManager.writeVarInt(out, verifyToken.length);
			out.write(verifyToken);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
