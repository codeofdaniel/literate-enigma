package minecraftbot.packet;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;

import minecraftbot.datamanaging.DataContent;
import minecraftbot.datamanaging.SpecialDataManager;

public class SendMessage implements DataContent {
	private String message;
	public SendMessage(String message) {
		this.message = message;
	}
	@Override
	public void dataContent(DataOutputStream out) {
		try {
			SpecialDataManager.writeVarInt(out, 0x01);
			SpecialDataManager.writeString(out, message, StandardCharsets.UTF_8);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
