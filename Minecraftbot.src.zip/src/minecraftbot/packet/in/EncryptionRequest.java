package minecraftbot.packet.in;

import java.io.DataInputStream;

import minecraftbot.datamanaging.SpecialDataManager;

public class EncryptionRequest extends InputPacket {
	//Packet-ID = 0x01
	public String serverID;
	public byte[] publicKey;
	public byte[] verifyToken;
	public EncryptionRequest(DataInputStream input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void readData(DataInputStream input) throws Exception {
		serverID = SpecialDataManager.readString(input);
		publicKey = new byte[SpecialDataManager.readVarInt(input)];
		input.readFully(publicKey);
		verifyToken = new byte[SpecialDataManager.readVarInt(input)];
		input.readFully(verifyToken);
	}

}
