package minecraftbot.packet.in;

import java.io.DataInputStream;

import minecraftbot.datamanaging.SpecialDataManager;

public class Disconnect extends InputPacket {
	public String reason;
	public Disconnect(DataInputStream input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void readData(DataInputStream input) throws Exception {
		reason = SpecialDataManager.readString(input);
	}

}
