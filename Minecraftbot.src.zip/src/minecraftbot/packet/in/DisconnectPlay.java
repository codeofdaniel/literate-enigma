package minecraftbot.packet.in;

import java.io.DataInputStream;

import minecraftbot.datamanaging.SpecialDataManager;

public class DisconnectPlay extends InputPacket {
	public String reason;
	public DisconnectPlay(DataInputStream input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void readData(DataInputStream input) throws Exception {
		reason = SpecialDataManager.readString(input);
	}

}
