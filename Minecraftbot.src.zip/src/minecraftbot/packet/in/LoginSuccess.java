package minecraftbot.packet.in;

import java.io.DataInputStream;

import minecraftbot.datamanaging.SpecialDataManager;

public class LoginSuccess extends InputPacket {
	public String uuid, username;
	public LoginSuccess(DataInputStream input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void readData(DataInputStream input) throws Exception {
		uuid = SpecialDataManager.readString(input);
		username = SpecialDataManager.readString(input);
	}

}
