package minecraftbot.packet.in;

import java.io.DataInputStream;

import minecraftbot.datamanaging.SpecialDataManager;

public class KeepAliveInput extends InputPacket {
	public int keepAliveID;
	public KeepAliveInput(DataInputStream input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void readData(DataInputStream input) throws Exception {
		keepAliveID = SpecialDataManager.readVarInt(input);
	}

}
