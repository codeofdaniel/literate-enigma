package minecraftbot.packet.in;

import java.io.DataInputStream;

public abstract class InputPacket {
	/**
	 * Diese Klasse darf erst dann initialisiert werden, wenn bei dem input eine VarInt als Packet-ID bereits gelesen worden ist.
	 * @param input
	 */
	public InputPacket(DataInputStream input) {
		try {
			this.readData(input);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public abstract void readData(DataInputStream input) throws Exception;
}
