package minecraftbot.packet.in;

import java.io.DataInputStream;

import minecraftbot.datamanaging.SpecialDataManager;

public class ChatMessage extends InputPacket {
	public String message;
	public byte position;
	public ChatMessage(DataInputStream input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void readData(DataInputStream input) throws Exception {
		message = SpecialDataManager.readString(input);
		position = input.readByte();
	}

}
