package minecrafttortunnel.run;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.TextField;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

import minecrafttortunnel.connect.Listener;
import minecrafttortunnel.connect.ListenerSocket;
import minecrafttortunnel.gui.CookieFileFrame;
import minecrafttortunnel.gui.StandardFrame;
import minecrafttortunnel.gui.def.CloseButton;
import minecrafttortunnel.gui.def.Logger;
import minecrafttortunnel.gui.def.NewIdentityButton;
import minecrafttortunnel.gui.def.TogglePremiumButton;
import minecrafttortunnel.tor.TorControl;

@SuppressWarnings("serial")
public class Starter extends StandardFrame {
	public static Listener listen;
	public static TorControl tc;
	public static void start() {
		try {
			tc = new TorControl();
			tc.authenticate();
			tc.useProxy();
		}
		catch (Exception e) {
			System.err.println("An exception occured while trying to use Tor:");
			e.printStackTrace();
			System.exit(0);
		}
		listen=new Listener();
		new Starter();
	}
	public static void main(String[] args) {
		new CookieFileFrame();
	}
	public static TextField serverIP = new TextField();
	public static TextField serverPort = new TextField();
	public static TextField connectionsCount = new TextField();
	public CloseButton closebutton;
	public NewIdentityButton newidentitybutton;
	public TogglePremiumButton toggle;
	public static Logger logger = new Logger();
	public static void log(Color color, String message) {
		Starter.logger.log(color, message);
	}
	public Starter() {
		this.setBackground(Color.YELLOW);
		Starter.serverIP.setText("ip");
		Starter.serverPort.setText("port");
		Starter.connectionsCount.setText("connections: 0");
		Starter.serverIP.setLocation(19, 49);
		Starter.serverPort.setLocation(19, 89);
		Starter.connectionsCount.setLocation(19, 844);
		Starter.serverIP.setSize(1327, 30);
		Starter.serverPort.setSize(1327, 30);
		Starter.connectionsCount.setSize(1327, 70);
		Starter.serverIP.setBackground(Color.WHITE);
		Starter.serverPort.setBackground(Color.WHITE);
		Starter.connectionsCount.setBackground(Color.WHITE);
		Starter.serverIP.setForeground(Color.BLACK);
		Starter.serverPort.setForeground(Color.BLACK);
		Starter.connectionsCount.setForeground(Color.BLACK);
		Starter.serverIP.setFont(new Font(null, 0, 20));
		Starter.serverPort.setFont(new Font(null, 0, 20));
		Starter.connectionsCount.setFont(new Font(null, 0, 40));
		this.newidentitybutton = new NewIdentityButton(this);
		this.closebutton = new CloseButton(this);
		this.toggle = new TogglePremiumButton(this);
		addWindowListener(new WindowAdapter()
		{
		  public void windowClosing(WindowEvent e)
		  {
			  ListenerSocket.closeAll();
			  try {
				  Listener.disabled=true;
				listen.serv.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			  System.exit(0);
		  }
		});
		setVisible(true);
		add(Starter.serverIP);
		add(Starter.serverPort);
		add(Starter.connectionsCount);
		Starter.serverIP.setEditable(true);
		Starter.connectionsCount.setEditable(false);
		Starter.serverPort.setVisible(true);
	}
	@Override
	public void paint(Graphics g) {
		   this.newidentitybutton.paint(g);
		    this.closebutton.paint(g);
		    this.toggle.paint(g);
		    g.setColor(Color.WHITE);
		    g.fillRect(19, 129, 1662, 705);
		    Starter.logger.paint(g);
	}
	@Override
	public int getFrameWidth() {
		// TODO Auto-generated method stub
		return 1700;
	}
	@Override
	public int getFrameHeight() {
		// TODO Auto-generated method stub
		return 1000;
	}
}
