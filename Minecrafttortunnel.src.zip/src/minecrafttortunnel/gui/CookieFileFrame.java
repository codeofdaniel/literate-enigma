package minecrafttortunnel.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.TextField;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import minecrafttortunnel.gui.def.SelectCookieFileButton;

public class CookieFileFrame extends StandardFrame {
	private static TextField cookieFileLocation = new TextField();
	private SelectCookieFileButton select;
	@Override
	public int getFrameWidth() {
		// TODO Auto-generated method stub
		return 1700;
	}
	public CookieFileFrame() {
		this.setBackground(Color.YELLOW);
		cookieFileLocation.setText("Path\\to\\control_auth_cookie");
		cookieFileLocation.setLocation(19, 49);
		cookieFileLocation.setSize(1327, 70);
		cookieFileLocation.setBackground(Color.WHITE);
		cookieFileLocation.setForeground(Color.BLACK);
		cookieFileLocation.setFont(new Font(null, 0, 40));
		this.select = new SelectCookieFileButton(this, cookieFileLocation);
		addWindowListener(new WindowAdapter()
		{
		  public void windowClosing(WindowEvent e)
		  {
			  System.exit(0);
		  }
		});
		setVisible(true);
		add(cookieFileLocation);
		cookieFileLocation.setEditable(true);
		cookieFileLocation.setVisible(true);
	}

	@Override
	public int getFrameHeight() {
		// TODO Auto-generated method stub
		return 200;
	}

	@Override
	public void paint(Graphics g) {
		this.select.paint(g);
	}

}
