package minecrafttortunnel.gui;

import java.awt.Graphics;

@SuppressWarnings("serial")
public abstract class StandardFrame extends DoubleBufferedFrame implements Runnable {
	public static final long frameRate = 10;
	public abstract int getFrameWidth();
	public abstract int getFrameHeight();
	public StandardFrame() {
		this.setSize(getFrameWidth(), getFrameHeight());
		this.setLayout(null);
	}
	@Override
	public void setVisible(boolean visible) {
		super.setVisible(visible);
		if (visible = true) {
			new Thread(this).start();
		}
	}
	@Override
	public void run() {
		while(this.isVisible()) {
			try {
				Thread.sleep(frameRate);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			this.repaint();
		}
	}
	@Override
	public abstract void paint(Graphics g);
}
