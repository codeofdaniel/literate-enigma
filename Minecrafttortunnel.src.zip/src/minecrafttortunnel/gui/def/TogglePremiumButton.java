package minecrafttortunnel.gui.def;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;

import minecrafttortunnel.gui.Button;

public class TogglePremiumButton extends Button {
	public static boolean premium = false;
	@Override
	public void buttonClicked(Frame containingFrame) {
		if (premium == false) {
			this.background = new Color(255,0,0,255);
			this.text = "premium enabled";
			premium = true;
			return;
		}
		if (premium == true) {
			this.background = new Color(0,255,0,255);
			this.text = "premium disabled";
			premium = false;
			return;
		}
	}
	public TogglePremiumButton(Frame f) {
		this.width = 325;
		this.height = 30;
		this.x = 1356;
		this.y = 89;
		this.font = new Font(null, 0, 20);
		this.background = Color.GREEN;
		this.text = "premium disabled";
		this.visible = true;
		setup(f);
	}
}
