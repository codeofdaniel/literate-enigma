package minecrafttortunnel.gui.def;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;

import minecrafttortunnel.connect.ListenerSocket;
import minecrafttortunnel.gui.Button;

public class CloseButton extends Button {

	@Override
	public void buttonClicked(Frame containingFrame) {
		ListenerSocket.closeAll();
	}
	public CloseButton(Frame f) {
		this.width = 325;
		this.height = 70;
		this.x = 1356;
		this.y = 844;
		this.font = new Font(null, 0, 40);
		this.background = Color.BLUE;
		this.text = "close all";
		this.visible = true;
		setup(f);
	}

}
