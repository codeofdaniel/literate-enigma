package minecrafttortunnel.gui.def;

import java.awt.Font;

import minecrafttortunnel.gui.LogGUI;

public class Logger extends LogGUI {
	public Logger() {
		setLocation(19, 129);
		this.font = new Font(null, 0, 20);
		this.lineSpace = 25;
		this.maxLines = 28;
	}
}
