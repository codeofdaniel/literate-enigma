package minecrafttortunnel.gui.def;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.TextField;

import minecrafttortunnel.gui.Button;
import minecrafttortunnel.gui.CookieFileFrame;
import minecrafttortunnel.run.Starter;
import minecrafttortunnel.tor.TorControl;

public class SelectCookieFileButton extends Button {
	private CookieFileFrame frame;
	private TextField t;
	@Override
	public void buttonClicked(Frame containingFrame) {
		TorControl.COOKIE_FILE = t.getText();
		frame.setVisible(false);
		Starter.start();
	}
	public SelectCookieFileButton(CookieFileFrame frame, TextField textField) {
		t = textField;
		this.width = 325;
		this.height = 70;
		this.x = 1356;
		this.y = 49;
		this.font = new Font(null, 0, 60);
		this.background = Color.GREEN;
		this.text = "select";
		this.visible = true;
		setup(frame);
		this.frame = frame;
	}

}
