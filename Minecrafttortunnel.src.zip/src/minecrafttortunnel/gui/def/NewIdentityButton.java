package minecrafttortunnel.gui.def;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.io.IOException;

import minecrafttortunnel.connect.ListenerSocket;
import minecrafttortunnel.gui.Button;
import minecrafttortunnel.gui.LogGUI;
import minecrafttortunnel.run.Starter;

public class NewIdentityButton extends Button {

	@Override
	public void buttonClicked(Frame containingFrame) {
		ListenerSocket.closeAll();
		try {
			Starter.tc.newIdentity();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		Starter.log(Color.BLUE, "[" + LogGUI.getCurrentTime() + "] Your identity has been changed!");
	}
	public NewIdentityButton(Frame f) {
		this.width = 325;
		this.height = 30;
		this.x = 1356;
		this.y = 49;
		this.font = new Font(null, 0, 20);
		this.background = Color.GREEN;
		this.text = "new identity";
		this.visible = true;
		setup(f);
	}

}
