package minecrafttortunnel.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LogGUI {
	public static String getCurrentTime() {
		DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		Date date = new Date();
		return dateFormat.format(date);
	}
	private static class ListElement {
		public Color color;
		public String string;
		public ListElement(Color c, String s) {
			color = c;
			string = s;
		}
	}
	public int x, y, maxLines, lineSpace;
	public Font font;
	private List<ListElement> list = new ArrayList<ListElement>();
	public void setLocation(int x, int y) {
		this.x = x;this.y = y;
	}
	public void paint(Graphics g) {
		g.setFont(font);
		int y = this.y + lineSpace;
		for (int i = 0; i < list.size(); i++) {
			ListElement e = list.get(i);
			g.setColor(e.color);
			g.drawString(e.string, x, y);
			y += lineSpace;
		}
	}
	public void log(Color color, String text) {
		list.add(new ListElement(color,text));
		if (list.size() > maxLines) {
			list.remove(0);
		}
	}
}
