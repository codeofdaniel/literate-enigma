package minecrafttortunnel.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JLabel;

public abstract class Button implements MouseListener {
	public int x, y, width, height=50, opaqueChange=5, mousePressAlphaChange=50, stringHeightReduce = 13, stringRightPushing = 4;
	public Color foreground=Color.BLACK, background;
	public long threadSleep=5;
	public Font font=new Font(null, Font.BOLD, 32);
	public String text;
	public boolean visible;
	private JLabel label;
	private Frame frame;
	public void setup(Frame frame) {
		label = new JLabel();
		label.setLocation(x, y);
		label.setSize(width, height);
		frame.add(label);
		this.frame = frame;
		label.setVisible(true);
		label.setOpaque(true);
		background = new Color(background.getRed(), background.getGreen(), background.getBlue(), 0);
		label.addMouseListener(this);
	}
	public void disableAlpha() {
		background = new Color(background.getRed(), background.getGreen(), background.getBlue(), 0);
	}
	public void paint(Graphics g) {
		if (!visible) {
			return;
		}
		g.setColor(background);
		g.fillRect(x, y, width, height);
		g.setColor(foreground);
		g.setFont(font);
		g.drawString(text, x+stringRightPushing, y+height-stringHeightReduce);
	}
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	private boolean stopall;
	private boolean mouseIn;
	@Override
	public void mouseEntered(MouseEvent arg0) {
		if (!visible) {
			return;
		}
		mouseIn = true;
		new Thread(new ColorIncreaser()).start();
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		if (!visible) {
			return;
		}
		mouseIn = false;
		new Thread(new ColorDecreaser()).start();
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		if (!visible) {
			return;
		}
		this.stopall = true;
		background = new Color(background.getRed(), background.getGreen(), background.getBlue(), 255-this.mousePressAlphaChange);
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		if (!visible) {
			return;
		}
		if (mouseIn = true) {
			background = new Color(background.getRed(), background.getGreen(), background.getBlue(), 255);
			this.stopall = false;
			this.buttonClicked(frame);
			return;
		}
		this.stopall = false;
		new Thread(new ColorDecreaser()).start();
	}
	public abstract void buttonClicked(Frame containingFrame);
	private class ColorIncreaser implements Runnable {
		@Override
		public void run() {
			for (int i = background.getAlpha(); i + opaqueChange <= 255;) {
				try {
					Thread.sleep(threadSleep);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (mouseIn && !stopall) {
					background = new Color(background.getRed(), background.getGreen(), background.getBlue(), i);
					i += opaqueChange;
					continue;
				}
				return;
			}
		}
	}
	private class ColorDecreaser implements Runnable {

		@Override
		public void run() {
			for (int i = background.getAlpha(); i - opaqueChange >= 0;) {
				try {
					Thread.sleep(threadSleep);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (mouseIn || stopall) {
					return;
				}
				background = new Color(background.getRed(), background.getGreen(), background.getBlue(), i);
				i -= opaqueChange;
			}
		}
		
	}
	
}
