package minecrafttortunnel.gui;

import java.awt.Color;
import java.awt.Graphics;

public abstract class GUIObject {
	public int x, y, width, height;
	public boolean insideObject(int x, int y) {
		if (x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + height) {
			return true;
		}
		return false;
	}
	public Color foreground, background;
	public abstract void paint(Graphics g);
}
