package minecrafttortunnel.gui;

import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;

@SuppressWarnings("serial")
public class DoubleBufferedFrame extends Frame {
	private Image dbImage;
	private Graphics dbGraphics;
	private boolean doubleBuffering;
	public void update(Graphics g)
	   {
	      //Double-Buffer initialisieren
	      if (dbImage == null) {
	         dbImage = createImage(
	            this.getSize().width,
	            this.getSize().height
	         );
	         dbGraphics = dbImage.getGraphics();
	      }
	      //Hintergrund l�schen
	      dbGraphics.setColor(getBackground());
	      dbGraphics.fillRect(
	         0,
	         0,
	         this.getSize().width,
	         this.getSize().height
	       );
	      //Vordergrund zeichnen
	      dbGraphics.setColor(getForeground());
	      paint(dbGraphics);
	      //Offscreen anzeigen
	      g.drawImage(dbImage,0,0,this);
	   }
	public boolean isDoubleBuffering() {
		return doubleBuffering;
	}
	public void setDoubleBuffering(boolean doubleBuffering) {
		this.doubleBuffering = doubleBuffering;
	}
}
