package minecrafttortunnel.connect;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import minecrafttortunnel.run.Starter;

public class Listener implements Runnable {
	public static boolean disabled;
	private static String getIp() {
		return Starter.serverIP.getText();
	}
	private static int getPort() {
		return Integer.parseInt(Starter.serverPort.getText());
	}
	public ServerSocket serv;
	public Listener() {
		try {
			serv = new ServerSocket(25565);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new Thread(this).start();
	}
	private boolean checker;
	private Socket tryAccept() {
		try {
			Socket socket = serv.accept();
			checker = true;
			return socket;
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	@Override
	public void run() {
		while(!disabled) {
			Socket accept = tryAccept();
			if (checker) {
				new ListenerSocketThread(accept, getIp(), getPort());
				checker = false;
			}
		}
	}
}
