package minecrafttortunnel.connect.util;

public abstract class Countdown implements Runnable {
	private int count;
	private int reset;
	private boolean finished;
	public abstract void finished();
	public Countdown(int c) {
		count =c;
		reset=c;
		new Thread(this).start();
	}
	public boolean isFinished() {
		return finished;
	}
	public void reset() {
		count = reset;
	}
	@Override
	public void run() {
		while(count > 0) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			count -= 1;
		}
		finished = true;
		this.finished();
	}
}
