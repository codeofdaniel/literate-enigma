package minecrafttortunnel.connect.util;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;

public class Handshake implements DataContent {
	private int version, port, status;
	private String ip;
	public Handshake(int protocolVersion, String ip, int port, int status) {
		this.port=port;
		version=protocolVersion;
		this.ip = ip;
		this.status = status;
	}
	@Override
	public void dataContent(DataOutputStream out) {
		try {
			SpecialDataManager.writeVarInt(out, 0x00);
			SpecialDataManager.writeVarInt(out, version);
			SpecialDataManager.writeString(out, ip, StandardCharsets.UTF_8);
			out.writeShort(port);
			SpecialDataManager.writeVarInt(out, status);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
