package minecrafttortunnel.connect.util;

import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;

public class DisconnectLogin implements DataContent {
	private String r;
	public DisconnectLogin(String reason) {
		r = "\"" + reason + "\"";
	}
	@Override
	public void dataContent(DataOutputStream out) {
		try {
			SpecialDataManager.writeVarInt(out, 0x00);
			SpecialDataManager.writeString(out, r, StandardCharsets.UTF_8);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
