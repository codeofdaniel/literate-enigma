package minecrafttortunnel.connect.util;

import java.io.DataOutputStream;

public interface DataContent {
	/**
	 * Hier wird als erstes die Packet-ID und dann abfolgend alle Daten des Packets in "out" geschrieben.
	 * @param out
	 */
	public void dataContent(DataOutputStream out);
}
