package minecrafttortunnel.connect.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;

public abstract class DataTransporter implements Runnable {
	private Socket socket,clientSocket;
	private DataInputStream get;
	private DataOutputStream send;
	private boolean process = true;
	public void stop() {
		process=false;
	}
	public DataTransporter(DataInputStream getter, DataOutputStream sender, Socket socket, Socket s2) {
		this.socket = socket;
		get = getter;
		send = sender;
		clientSocket = s2;
		new Thread(this).start();
	}
	public abstract void dataWritten();
	@Override
	public void run() {
		while(process) {
			if (socket.isClosed()||clientSocket.isClosed()) {
				return;
			}
			try {
				int available = get.available();
				byte[] readBytes = new byte[available];
				get.readFully(readBytes);
				send.write(readBytes);
				if (available > 0) {
					this.dataWritten();
				}
			} catch (EOFException e) {
				
			}
			catch (SocketException e) {
				stop();
				return;
			}
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
