package minecrafttortunnel.connect.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;


public class Packet {
	int length;
	public int getLength() {
		return length;
	}
	byte[] data;
	public DataInputStream getData() {
		ByteArrayInputStream input = new ByteArrayInputStream(data);
		return new DataInputStream(input);
	}
	@SuppressWarnings("unused")
	private Packet(DataInputStream input) throws Exception {
		length = SpecialDataManager.readVarInt(input);
		data = new byte[length];
		input.readFully(data);
	}
	public Packet(DataContent content) {
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		DataOutputStream out = new DataOutputStream(buffer);
		content.dataContent(out);
		data = buffer.toByteArray();
		length = data.length;
	}
	public void send(DataOutputStream output) throws Exception {
		SpecialDataManager.writeVarInt(output, length);
		output.write(data);
	}
}
