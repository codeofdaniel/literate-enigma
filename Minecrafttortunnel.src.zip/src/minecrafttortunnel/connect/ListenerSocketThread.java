package minecrafttortunnel.connect;

import java.net.Socket;

public class ListenerSocketThread implements Runnable {
	private Socket s;
	private String i;
	private int p;
	public ListenerSocketThread(Socket accept, String ip, int port) {
		s=accept;
		i=ip;
		p=port;
		new Thread(this).start();
	}
	@Override
	public void run() {
		new ListenerSocket(s,i,p);
	}
}
