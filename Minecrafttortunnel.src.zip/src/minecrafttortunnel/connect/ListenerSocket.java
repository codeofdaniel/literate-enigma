package minecrafttortunnel.connect;

import java.awt.Color;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

import minecrafttortunnel.connect.util.Countdown;
import minecrafttortunnel.connect.util.DataTransporter;
import minecrafttortunnel.connect.util.DisconnectLogin;
import minecrafttortunnel.connect.util.Handshake;
import minecrafttortunnel.connect.util.LoginStart;
import minecrafttortunnel.connect.util.Packet;
import minecrafttortunnel.connect.util.SpecialDataManager;
import minecrafttortunnel.gui.LogGUI;
import minecrafttortunnel.gui.def.TogglePremiumButton;
import minecrafttortunnel.run.Starter;

public class ListenerSocket {
	private String paramIp;
	private int paramPort;
	private boolean closed;
	public static final List<ListenerSocket> active = new ArrayList<ListenerSocket>();
	public static void closeAll() {
		for (ListenerSocket s : active) {
			s.closeSave();
		}
		active.clear();
		Starter.connectionsCount.setText("connections: 0");
	}
	private Countdown timeout;
	public void close() {
		closeSave();
		active.remove(this);
		Starter.connectionsCount.setText("connections: " + active.size());
	}
	private void closeSave() {
		try {
			client.close();
		} catch (Exception e) {
		}
		try {
			server.close();
			closed = true;
		} catch (Exception e) {
		}
		if (active.contains(this)) {
		Starter.log(Color.RED, "[" + LogGUI.getCurrentTime() + "] Disconnected from " + paramIp + ", " + paramPort);}
	}
	private Socket client, server;
	private DataInputStream clientIn, serverIn;
	private DataOutputStream clientOut, serverOut;
	private void tryClientClose() {
		try {
			client.close();
		}
		catch (Exception e) {
			
		}
	}
	private void tryServerClose() {
		try {
			server.close();
		}
		catch (Exception e) {
			
		}
	}
	public ListenerSocket(Socket accept, String ip, int port) {
		paramIp = ip;
		paramPort = port;
		client = accept;
		int protocolVersion = 0;
		int status = 0;
		try {
			clientIn = new DataInputStream(client.getInputStream());
			clientOut = new DataOutputStream(client.getOutputStream());
			SpecialDataManager.readVarInt(clientIn);
			SpecialDataManager.readVarInt(clientIn);
			protocolVersion = SpecialDataManager.readVarInt(clientIn);
			SpecialDataManager.readString(clientIn);
			clientIn.readShort();
			status = SpecialDataManager.readVarInt(clientIn);
		}
		catch (Exception e) {
			this.tryClientClose();
			this.tryServerClose();
			e.printStackTrace();
			return;
		}
		active.add(this);
		try {
			if (closed) {
				this.tryClientClose();
				this.tryServerClose();
				return;
			}
			try {
				server = new Socket(ip, port);
			}
			catch (SocketException offlineexception) {
				this.tryServerClose();
				if (status == 2) {
					SpecialDataManager.readVarInt(clientIn);
					SpecialDataManager.readVarInt(clientIn);
					SpecialDataManager.readString(clientIn);
					new Packet(new DisconnectLogin("[MinecraftTorConnect] This server seems to be offline.")).send(clientOut);}
					this.tryClientClose();
					try {
						active.remove(this);
					}
					catch (Exception e) {
						
					}
					return;
			}
			if (closed) {
				this.tryClientClose();
				this.tryServerClose();
				return;
			}
		}
		catch (Exception e) {
			this.tryClientClose();
			this.tryServerClose();
			e.printStackTrace();
			return;
		}
		try {
			serverIn = new DataInputStream(server.getInputStream());
			serverOut = new DataOutputStream(server.getOutputStream());
			new Packet(new Handshake(protocolVersion, ip, port, status)).send(serverOut);
		}
		catch (Exception e) {
			this.tryClientClose();
			this.tryServerClose();
			e.printStackTrace();
			return;
		}
		//TODO new code
		if (status == 2) {
			try {
				SpecialDataManager.readVarInt(clientIn);
				SpecialDataManager.readVarInt(clientIn);
				String username = SpecialDataManager.readString(clientIn);
				new Packet(new LoginStart(username)).send(serverOut);
				int length = SpecialDataManager.readVarInt(serverIn);
				byte[] data = new byte[length];
				serverIn.readFully(data);
				ByteArrayInputStream i = new ByteArrayInputStream(data);
				DataInputStream tempin = new DataInputStream(i);
				int packedId = SpecialDataManager.readVarInt(tempin);
				if ((packedId == 0x01) && (!TogglePremiumButton.premium)) {
					this.tryServerClose();
					new Packet(new DisconnectLogin("[MinecraftTorConnect] You can't connect with premium minecraft servers using this tool. That would cause your client to send an unproxied request to the mojang auth servers which would unmask your real ip address and thus break your anonymity.")).send(clientOut);
					this.tryClientClose();
					try {
						active.remove(this);
					}
					catch (Exception e) {
						
					}
					return;
				}
				SpecialDataManager.writeVarInt(clientOut, length);
				clientOut.write(data);
			}
			catch (Exception e) {
				this.tryClientClose();
				this.tryServerClose();
				e.printStackTrace();
				return;
			}
		}
		//TODO new code
		timeout = new Countdown(15) {

			@Override
			public void finished() {
				close();
			}
			
		};
		new DataTransporter(clientIn, serverOut, client, server) {

			@Override
			public void dataWritten() {
				timeout.reset();
			}
			
		};
		new DataTransporter(serverIn, clientOut, client, server) {

			@Override
			public void dataWritten() {
				timeout.reset();
			}
			
		};
		Starter.connectionsCount.setText("connections: " + active.size());
		Starter.log(Color.GREEN, "[" + LogGUI.getCurrentTime() + "] Connected to " + ip + ", " + port + ", status: " + status);
	}
}
